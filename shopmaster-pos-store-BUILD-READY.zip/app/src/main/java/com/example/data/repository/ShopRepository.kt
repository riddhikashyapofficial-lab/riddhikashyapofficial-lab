package com.example.data.repository

import com.example.data.AppDatabase
import com.example.data.model.AppNotification
import com.example.data.model.AuditLog
import com.example.data.model.CashRegisterSession
import com.example.data.model.CashTransaction
import com.example.data.model.CashTransactionType
import com.example.data.model.Category
import com.example.data.model.Customer
import com.example.data.model.CustomerAddress
import com.example.data.model.CustomerRepeatTier
import com.example.data.model.DeliveryType
import com.example.data.model.Employee
import com.example.data.model.Expense
import com.example.data.model.InventoryMovement
import com.example.data.model.MovementType
import com.example.data.model.NotificationType
import com.example.data.model.OfflineSale
import com.example.data.model.OfflineSaleItem
import com.example.data.model.Order
import com.example.data.model.OrderItem
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentStatus
import com.example.data.model.Product
import com.example.data.model.PurchaseOrder
import com.example.data.model.PurchaseOrderItem
import com.example.data.model.ShopSettings
import com.example.data.model.Supplier
import com.example.data.model.UserRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import kotlin.math.max

data class CartItem(
    val product: Product,
    val quantity: Double
)

class ShopRepository(private val db: AppDatabase) {

    // DAOs
    val productDao = db.productDao()
    val customerDao = db.customerDao()
    val orderDao = db.orderDao()
    val offlineSaleDao = db.offlineSaleDao()
    val cashDao = db.cashDao()
    val expenseDao = db.expenseDao()
    val purchaseDao = db.purchaseDao()
    val auditLogDao = db.auditLogDao()
    val notificationDao = db.notificationDao()
    val shopSettingsDao = db.shopSettingsDao()
    val employeeDao = db.employeeDao()

    // Reactive Flows
    val allProducts: Flow<List<Product>> = productDao.getAllProducts()
    val availableProducts: Flow<List<Product>> = productDao.getAvailableProducts()
    val lowStockProducts: Flow<List<Product>> = productDao.getLowStockProducts()
    val allCategories: Flow<List<Category>> = productDao.getAllCategories()
    val allInventoryMovements: Flow<List<InventoryMovement>> = productDao.getAllMovements()
    val allCustomers: Flow<List<Customer>> = customerDao.getAllCustomers()
    val allOrders: Flow<List<Order>> = orderDao.getAllOrders()
    val allOrderItems: Flow<List<OrderItem>> = orderDao.getAllOrderItems()
    val allOfflineSales: Flow<List<OfflineSale>> = offlineSaleDao.getAllSales()
    val allOfflineSaleItems: Flow<List<OfflineSaleItem>> = offlineSaleDao.getAllSaleItems()
    val currentOpenSession: Flow<CashRegisterSession?> = cashDao.getCurrentOpenSession()
    val allSessions: Flow<List<CashRegisterSession>> = cashDao.getAllSessions()
    val allCashTransactions: Flow<List<CashTransaction>> = cashDao.getAllCashTransactions()
    val allExpenses: Flow<List<Expense>> = expenseDao.getAllExpenses()
    val allSuppliers: Flow<List<Supplier>> = purchaseDao.getAllSuppliers()
    val allPurchases: Flow<List<PurchaseOrder>> = purchaseDao.getAllPurchases()
    val allAuditLogs: Flow<List<AuditLog>> = auditLogDao.getAllAuditLogs()
    val allNotifications: Flow<List<AppNotification>> = notificationDao.getAllNotifications()
    val unreadNotificationsCount: Flow<Int> = notificationDao.getUnreadCount()
    val shopSettings: Flow<ShopSettings?> = shopSettingsDao.getSettings()
    val allEmployees: Flow<List<Employee>> = employeeDao.getAllEmployees()

    // ----------------------------------------------------
    // 1. OFFLINE POS SALE EXECUTION (ONE MASTER INVENTORY)
    // ----------------------------------------------------
    suspend fun processOfflineSale(
        cartItems: List<CartItem>,
        customer: Customer?,
        cashierName: String,
        subtotal: Double,
        discount: Double,
        tax: Double,
        totalAmount: Double,
        paymentMethod: PaymentMethod,
        notes: String = ""
    ): Result<Long> = withContext(Dispatchers.IO) {
        try {
            val invoiceNumber = "INV-${System.currentTimeMillis() % 1000000}"
            val customerId = customer?.id ?: 0L
            val customerName = customer?.name ?: "Walk-in Customer"
            val customerPhone = customer?.phone ?: ""

            // 1. Create Offline Sale Header
            val sale = OfflineSale(
                invoiceNumber = invoiceNumber,
                customerId = customerId,
                customerName = customerName,
                customerPhone = customerPhone,
                cashierName = cashierName,
                subtotal = subtotal,
                discount = discount,
                tax = tax,
                totalAmount = totalAmount,
                paymentMethod = paymentMethod,
                paymentStatus = PaymentStatus.PAID,
                notes = notes
            )
            val saleId = offlineSaleDao.insertSale(sale)

            // 2. Process Items & Master Inventory Reduction
            val saleItems = mutableListOf<OfflineSaleItem>()
            for (item in cartItems) {
                val currentProduct = productDao.getProductById(item.product.id) ?: item.product
                val prevStock = currentProduct.currentStock
                val newStock = max(0.0, prevStock - item.quantity)

                // Update stock in Master Inventory
                productDao.updateStock(item.product.id, newStock)
                if (newStock <= 0.0 && !currentProduct.allowBackorders) {
                    productDao.updateAvailability(item.product.id, false)
                }

                // Log Inventory Movement
                productDao.insertMovement(
                    InventoryMovement(
                        productId = item.product.id,
                        productName = item.product.name,
                        quantity = -item.quantity,
                        movementType = MovementType.OFFLINE_SALE,
                        previousStock = prevStock,
                        newStock = newStock,
                        responsibleUser = cashierName,
                        reason = "POS Sale Invoice #$invoiceNumber",
                        referenceNumber = invoiceNumber
                    )
                )

                // Check Low Stock Notification
                if (newStock <= currentProduct.minStockLevel) {
                    notificationDao.insertNotification(
                        AppNotification(
                            title = "Low Stock Alert: ${currentProduct.name}",
                            message = "Remaining stock is ${newStock.toInt()} ${currentProduct.unit}. Minimum threshold is ${currentProduct.minStockLevel.toInt()}.",
                            type = NotificationType.STOCK_ALERT
                        )
                    )
                }

                saleItems.add(
                    OfflineSaleItem(
                        saleId = saleId,
                        productId = item.product.id,
                        productName = item.product.name,
                        unitPrice = item.product.sellingPrice,
                        costPrice = item.product.costPrice,
                        unit = item.product.unit,
                        quantity = item.quantity,
                        totalPrice = item.product.sellingPrice * item.quantity
                    )
                )
            }
            offlineSaleDao.insertSaleItems(saleItems)

            // 3. Cash Management update if paid by Cash
            if (paymentMethod == PaymentMethod.CASH) {
                val openSession = cashDao.getCurrentOpenSessionDirect()
                if (openSession != null) {
                    val newCashSales = openSession.totalCashSales + totalAmount
                    val newExpected = openSession.expectedClosingCash + totalAmount
                    cashDao.updateSession(
                        openSession.copy(
                            totalCashSales = newCashSales,
                            expectedClosingCash = newExpected
                        )
                    )
                    cashDao.insertCashTransaction(
                        CashTransaction(
                            sessionId = openSession.id,
                            type = CashTransactionType.CASH_SALE_POS,
                            amount = totalAmount,
                            isCredit = true,
                            description = "POS Cash Sale #$invoiceNumber ($customerName)",
                            referenceId = invoiceNumber,
                            operatorName = cashierName
                        )
                    )
                }
            }

            // 4. Update Customer stats & Repeat Tier
            if (customer != null && customer.id > 0) {
                val updatedCustomer = recalculateCustomerStats(
                    customer = customer,
                    additionalSpend = totalAmount,
                    isOnline = false
                )
                customerDao.updateCustomer(updatedCustomer)
            }

            // 5. Audit Log
            auditLogDao.insertAuditLog(
                AuditLog(
                    userName = cashierName,
                    userRole = UserRole.CASHIER,
                    action = "OFFLINE_POS_SALE",
                    itemType = "OFFLINE_SALE",
                    itemId = invoiceNumber,
                    details = "Completed POS bill #$invoiceNumber for $customerName. Total: $totalAmount ($paymentMethod)",
                    newValue = "₹$totalAmount"
                )
            )

            Result.success(saleId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // 2. ONLINE CUSTOMER ORDER PLACEMENT (ONE MASTER INVENTORY)
    // ----------------------------------------------------
    suspend fun placeCustomerOrder(
        cartItems: List<CartItem>,
        customer: Customer,
        deliveryType: DeliveryType,
        deliveryAddress: String,
        deliveryInstructions: String,
        paymentMethod: PaymentMethod,
        deliveryCharge: Double,
        discount: Double,
        notes: String = ""
    ): Result<Long> = withContext(Dispatchers.IO) {
        try {
            val orderNumber = "ORD-${System.currentTimeMillis() % 1000000}"
            val subtotal = cartItems.sumOf { it.product.sellingPrice * it.quantity }
            val totalAmount = max(0.0, subtotal + deliveryCharge - discount)

            val order = Order(
                orderNumber = orderNumber,
                customerId = customer.id,
                customerName = customer.name,
                customerPhone = customer.phone,
                deliveryType = deliveryType,
                deliveryAddress = if (deliveryType == DeliveryType.HOME_DELIVERY) deliveryAddress else "Shop Counter Pickup",
                deliveryInstructions = deliveryInstructions,
                subtotal = subtotal,
                deliveryCharge = deliveryCharge,
                discount = discount,
                totalAmount = totalAmount,
                paymentMethod = paymentMethod,
                paymentStatus = if (paymentMethod == PaymentMethod.UPI) PaymentStatus.PAID else PaymentStatus.PENDING,
                orderStatus = OrderStatus.ORDER_RECEIVED,
                notes = notes
            )
            val orderId = orderDao.insertOrder(order)

            // Deduct Master Inventory immediately upon order placement
            val orderItems = mutableListOf<OrderItem>()
            for (item in cartItems) {
                val currentProduct = productDao.getProductById(item.product.id) ?: item.product
                val prevStock = currentProduct.currentStock
                val newStock = max(0.0, prevStock - item.quantity)

                productDao.updateStock(item.product.id, newStock)
                if (newStock <= 0.0 && !currentProduct.allowBackorders) {
                    productDao.updateAvailability(item.product.id, false)
                }

                productDao.insertMovement(
                    InventoryMovement(
                        productId = item.product.id,
                        productName = item.product.name,
                        quantity = -item.quantity,
                        movementType = MovementType.ONLINE_SALE,
                        previousStock = prevStock,
                        newStock = newStock,
                        responsibleUser = customer.name,
                        reason = "Customer Online Order #$orderNumber",
                        referenceNumber = orderNumber
                    )
                )

                if (newStock <= currentProduct.minStockLevel) {
                    notificationDao.insertNotification(
                        AppNotification(
                            title = "Low Stock Alert: ${currentProduct.name}",
                            message = "Remaining stock is ${newStock.toInt()} ${currentProduct.unit} after Order #$orderNumber.",
                            type = NotificationType.STOCK_ALERT
                        )
                    )
                }

                orderItems.add(
                    OrderItem(
                        orderId = orderId,
                        productId = item.product.id,
                        productName = item.product.name,
                        unitPrice = item.product.sellingPrice,
                        costPrice = item.product.costPrice,
                        unit = item.product.unit,
                        quantity = item.quantity,
                        totalPrice = item.product.sellingPrice * item.quantity
                    )
                )
            }
            orderDao.insertOrderItems(orderItems)

            // Update customer lifetime stats
            val updatedCustomer = recalculateCustomerStats(customer, totalAmount, isOnline = true)
            customerDao.updateCustomer(updatedCustomer)

            // Notification for shop staff
            notificationDao.insertNotification(
                AppNotification(
                    title = "New Customer Order #$orderNumber",
                    message = "${customer.name} placed a ${deliveryType.displayName} order for ₹$totalAmount.",
                    type = NotificationType.ORDER
                )
            )

            // Audit log
            auditLogDao.insertAuditLog(
                AuditLog(
                    userName = customer.name,
                    userRole = UserRole.CUSTOMER,
                    action = "PLACE_ORDER",
                    itemType = "ORDER",
                    itemId = orderNumber,
                    details = "New online order #$orderNumber placed for $deliveryType. Amount: ₹$totalAmount",
                    newValue = "₹$totalAmount"
                )
            )

            Result.success(orderId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // 3. ORDER STATUS UPDATE & COD CASH SYNCHRONIZATION
    // ----------------------------------------------------
    suspend fun updateOrderStatus(
        orderId: Long,
        newStatus: OrderStatus,
        operatorName: String = "Admin"
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val order = orderDao.getOrderById(orderId) ?: return@withContext Result.failure(Exception("Order not found"))
            val prevStatus = order.orderStatus
            if (prevStatus == newStatus) return@withContext Result.success(Unit)

            orderDao.updateOrderStatus(orderId, newStatus)

            // If order transitioned to DELIVERED or COMPLETED with pending cash payment -> mark as PAID and record cash into register!
            if ((newStatus == OrderStatus.DELIVERED || newStatus == OrderStatus.COMPLETED) && order.paymentStatus == PaymentStatus.PENDING) {
                orderDao.updatePaymentStatus(orderId, PaymentStatus.PAID)

                // Cash inflow to open session
                val openSession = cashDao.getCurrentOpenSessionDirect()
                if (openSession != null) {
                    val isCod = order.deliveryType == DeliveryType.HOME_DELIVERY
                    val transactionType = if (isCod) CashTransactionType.COD_DELIVERY else CashTransactionType.PICKUP_PAYMENT

                    val updatedSession = if (isCod) {
                        openSession.copy(
                            totalCodCollected = openSession.totalCodCollected + order.totalAmount,
                            expectedClosingCash = openSession.expectedClosingCash + order.totalAmount
                        )
                    } else {
                        openSession.copy(
                            totalPickupCashCollected = openSession.totalPickupCashCollected + order.totalAmount,
                            expectedClosingCash = openSession.expectedClosingCash + order.totalAmount
                        )
                    }
                    cashDao.updateSession(updatedSession)

                    cashDao.insertCashTransaction(
                        CashTransaction(
                            sessionId = openSession.id,
                            type = transactionType,
                            amount = order.totalAmount,
                            isCredit = true,
                            description = if (isCod) "COD collected for Order #${order.orderNumber} (${order.customerName})" else "Pickup counter cash for Order #${order.orderNumber}",
                            referenceId = order.orderNumber,
                            operatorName = operatorName
                        )
                    )
                }
            }

            // If CANCELLED or REFUNDED, return stock to Master Inventory
            if ((newStatus == OrderStatus.CANCELLED || newStatus == OrderStatus.REFUNDED) &&
                (prevStatus != OrderStatus.CANCELLED && prevStatus != OrderStatus.REFUNDED)) {
                val items = orderDao.getOrderItemsList(orderId)
                for (item in items) {
                    val p = productDao.getProductById(item.productId)
                    if (p != null) {
                        val prevStock = p.currentStock
                        val newStock = prevStock + item.quantity
                        productDao.updateStock(p.id, newStock)
                        if (newStock > 0.0) {
                            productDao.updateAvailability(p.id, true)
                        }

                        productDao.insertMovement(
                            InventoryMovement(
                                productId = p.id,
                                productName = p.name,
                                quantity = item.quantity,
                                movementType = if (newStatus == OrderStatus.REFUNDED) MovementType.RETURNED else MovementType.MANUAL_ADJUSTMENT,
                                previousStock = prevStock,
                                newStock = newStock,
                                responsibleUser = operatorName,
                                reason = "Order #${order.orderNumber} $newStatus - Stock restored",
                                referenceNumber = order.orderNumber
                            )
                        )
                    }
                }
            }

            // Audit log
            auditLogDao.insertAuditLog(
                AuditLog(
                    userName = operatorName,
                    userRole = UserRole.OWNER,
                    action = "UPDATE_ORDER_STATUS",
                    itemType = "ORDER",
                    itemId = order.orderNumber,
                    details = "Order #${order.orderNumber} status changed to ${newStatus.displayName}",
                    previousValue = prevStatus.displayName,
                    newValue = newStatus.displayName
                )
            )

            // Notification
            notificationDao.insertNotification(
                AppNotification(
                    title = "Order #${order.orderNumber} ${newStatus.displayName}",
                    message = "Status updated to ${newStatus.displayName} for ${order.customerName}.",
                    type = NotificationType.ORDER
                )
            )

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun assignDeliveryStaff(
        orderId: Long,
        staffId: Long,
        staffName: String,
        operatorName: String = "Admin"
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val order = orderDao.getOrderById(orderId) ?: return@withContext Result.failure(Exception("Order not found"))
            orderDao.assignDeliveryStaff(orderId, staffId, staffName)
            if (order.orderStatus == OrderStatus.PREPARING || order.orderStatus == OrderStatus.CONFIRMED) {
                orderDao.updateOrderStatus(orderId, OrderStatus.OUT_FOR_DELIVERY)
            }

            notificationDao.insertNotification(
                AppNotification(
                    title = "Delivery Assigned: Order #${order.orderNumber}",
                    message = "Assigned to $staffName for delivery to ${order.customerName}.",
                    type = NotificationType.DELIVERY
                )
            )

            auditLogDao.insertAuditLog(
                AuditLog(
                    userName = operatorName,
                    userRole = UserRole.OWNER,
                    action = "ASSIGN_DELIVERY",
                    itemType = "ORDER",
                    itemId = order.orderNumber,
                    details = "Assigned Order #${order.orderNumber} to delivery agent $staffName",
                    newValue = staffName
                )
            )

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // 4. STOCK-IN / SUPPLIER PURCHASES (ONE MASTER INVENTORY)
    // ----------------------------------------------------
    suspend fun recordPurchaseOrder(
        supplier: Supplier,
        invoiceNumber: String,
        items: List<PurchaseOrderItem>,
        paymentMethod: PaymentMethod,
        operatorName: String = "Owner",
        notes: String = ""
    ): Result<Long> = withContext(Dispatchers.IO) {
        try {
            val totalAmount = items.sumOf { it.total }
            val purchaseOrder = PurchaseOrder(
                invoiceNumber = invoiceNumber,
                supplierId = supplier.id,
                supplierName = supplier.name,
                totalAmount = totalAmount,
                paymentStatus = PaymentStatus.PAID,
                paymentMethod = paymentMethod,
                notes = notes,
                createdBy = operatorName
            )
            val poId = purchaseDao.insertPurchaseOrder(purchaseOrder)

            val poItemsWithId = items.map { it.copy(purchaseOrderId = poId) }
            purchaseDao.insertPurchaseItems(poItemsWithId)

            // Update Master Inventory stock & log movements
            for (item in items) {
                val currentProduct = productDao.getProductById(item.productId)
                if (currentProduct != null) {
                    val prevStock = currentProduct.currentStock
                    val newStock = prevStock + item.quantity

                    // Update product cost price if changed
                    val updatedProduct = currentProduct.copy(
                        currentStock = newStock,
                        costPrice = item.purchasePrice,
                        isAvailable = true,
                        updatedAt = System.currentTimeMillis()
                    )
                    productDao.updateProduct(updatedProduct)

                    productDao.insertMovement(
                        InventoryMovement(
                            productId = currentProduct.id,
                            productName = currentProduct.name,
                            quantity = item.quantity,
                            movementType = MovementType.STOCK_RECEIVED,
                            previousStock = prevStock,
                            newStock = newStock,
                            responsibleUser = operatorName,
                            reason = "Stock Received from ${supplier.name} (Inv #$invoiceNumber)",
                            referenceNumber = invoiceNumber
                        )
                    )
                }
            }

            // Also record expense if paid by Cash
            if (paymentMethod == PaymentMethod.CASH) {
                addExpense(
                    category = com.example.data.model.ExpenseCategory.PURCHASES,
                    amount = totalAmount,
                    paymentMethod = PaymentMethod.CASH,
                    description = "Stock purchase from ${supplier.name} (Inv #$invoiceNumber)",
                    addedBy = operatorName,
                    receiptNote = invoiceNumber
                )
            }

            auditLogDao.insertAuditLog(
                AuditLog(
                    userName = operatorName,
                    userRole = UserRole.STOCK_STAFF,
                    action = "STOCK_PURCHASE_RECEIVED",
                    itemType = "PURCHASE_ORDER",
                    itemId = invoiceNumber,
                    details = "Stock Inward of ${items.size} items from ${supplier.name}. Total: ₹$totalAmount",
                    newValue = "₹$totalAmount"
                )
            )

            Result.success(poId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // 5. STOCK ADJUSTMENT (DAMAGED / LOST / MANUAL)
    // ----------------------------------------------------
    suspend fun adjustStock(
        productId: Long,
        adjustmentQuantity: Double, // Negative for damage/loss, positive for found
        movementType: MovementType,
        reason: String,
        operatorName: String = "Staff"
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val product = productDao.getProductById(productId) ?: return@withContext Result.failure(Exception("Product not found"))
            val prevStock = product.currentStock
            val newStock = max(0.0, prevStock + adjustmentQuantity)

            productDao.updateStock(productId, newStock)
            if (newStock <= 0.0 && !product.allowBackorders) {
                productDao.updateAvailability(productId, false)
            }

            productDao.insertMovement(
                InventoryMovement(
                    productId = productId,
                    productName = product.name,
                    quantity = adjustmentQuantity,
                    movementType = movementType,
                    previousStock = prevStock,
                    newStock = newStock,
                    responsibleUser = operatorName,
                    reason = reason
                )
            )

            auditLogDao.insertAuditLog(
                AuditLog(
                    userName = operatorName,
                    userRole = UserRole.STOCK_STAFF,
                    action = "STOCK_ADJUSTMENT",
                    itemType = "PRODUCT",
                    itemId = product.id.toString(),
                    details = "Adjusted ${product.name} stock by $adjustmentQuantity ${product.unit} ($movementType). Reason: $reason",
                    previousValue = "$prevStock ${product.unit}",
                    newValue = "$newStock ${product.unit}"
                )
            )

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // 6. CASH REGISTER MANAGEMENT
    // ----------------------------------------------------
    suspend fun openCashRegister(
        openingCash: Double,
        operatorName: String = "Owner"
    ): Result<Long> = withContext(Dispatchers.IO) {
        try {
            val session = CashRegisterSession(
                openedAt = System.currentTimeMillis(),
                openedBy = operatorName,
                openingCash = openingCash,
                expectedClosingCash = openingCash,
                isClosed = false
            )
            val sessionId = cashDao.insertSession(session)

            cashDao.insertCashTransaction(
                CashTransaction(
                    sessionId = sessionId,
                    type = CashTransactionType.OPENING_BALANCE,
                    amount = openingCash,
                    isCredit = true,
                    description = "Opening Cash Register Float",
                    operatorName = operatorName
                )
            )

            auditLogDao.insertAuditLog(
                AuditLog(
                    userName = operatorName,
                    userRole = UserRole.OWNER,
                    action = "OPEN_CASH_REGISTER",
                    itemType = "CASH_DRAWER",
                    itemId = sessionId.toString(),
                    details = "Opened daily cash register session with ₹$openingCash",
                    newValue = "₹$openingCash"
                )
            )

            Result.success(sessionId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun closeCashRegister(
        sessionId: Long,
        actualPhysicalCash: Double,
        discrepancyNotes: String,
        operatorName: String = "Owner"
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val session = cashDao.getSessionById(sessionId) ?: return@withContext Result.failure(Exception("Session not found"))
            val expectedCash = session.expectedClosingCash
            val discrepancy = actualPhysicalCash - expectedCash

            val updatedSession = session.copy(
                closedAt = System.currentTimeMillis(),
                closedBy = operatorName,
                actualPhysicalCash = actualPhysicalCash,
                discrepancy = discrepancy,
                discrepancyNotes = discrepancyNotes,
                isClosed = true
            )
            cashDao.updateSession(updatedSession)

            // If discrepancy exists, notify owner
            if (discrepancy != 0.0) {
                notificationDao.insertNotification(
                    AppNotification(
                        title = "Cash Discrepancy Alert",
                        message = "Register closed with discrepancy of ₹$discrepancy (Expected: ₹$expectedCash, Actual: ₹$actualPhysicalCash).",
                        type = NotificationType.CASH_ALERT
                    )
                )
            }

            auditLogDao.insertAuditLog(
                AuditLog(
                    userName = operatorName,
                    userRole = UserRole.OWNER,
                    action = "CLOSE_CASH_REGISTER",
                    itemType = "CASH_DRAWER",
                    itemId = sessionId.toString(),
                    details = "Closed cash register. Expected: ₹$expectedCash, Physical Cash: ₹$actualPhysicalCash, Difference: ₹$discrepancy",
                    previousValue = "₹$expectedCash",
                    newValue = "₹$actualPhysicalCash"
                )
            )

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addExpense(
        category: com.example.data.model.ExpenseCategory,
        amount: Double,
        paymentMethod: PaymentMethod,
        description: String,
        addedBy: String = "Owner",
        receiptNote: String = ""
    ): Result<Long> = withContext(Dispatchers.IO) {
        try {
            val expense = Expense(
                category = category,
                amount = amount,
                date = System.currentTimeMillis(),
                paymentMethod = paymentMethod,
                description = description,
                addedBy = addedBy,
                receiptNote = receiptNote
            )
            val expenseId = expenseDao.insertExpense(expense)

            // If paid from cash drawer, deduct from active session
            if (paymentMethod == PaymentMethod.CASH) {
                val openSession = cashDao.getCurrentOpenSessionDirect()
                if (openSession != null) {
                    cashDao.updateSession(
                        openSession.copy(
                            totalCashExpenses = openSession.totalCashExpenses + amount,
                            expectedClosingCash = openSession.expectedClosingCash - amount
                        )
                    )
                    cashDao.insertCashTransaction(
                        CashTransaction(
                            sessionId = openSession.id,
                            type = CashTransactionType.EXPENSE_PAID,
                            amount = amount,
                            isCredit = false,
                            description = "Cash Expense: ${category.displayName} - $description",
                            referenceId = expenseId.toString(),
                            operatorName = addedBy
                        )
                    )
                }
            }

            auditLogDao.insertAuditLog(
                AuditLog(
                    userName = addedBy,
                    userRole = UserRole.OWNER,
                    action = "ADD_EXPENSE",
                    itemType = "EXPENSE",
                    itemId = expenseId.toString(),
                    details = "Added ${category.displayName} expense of ₹$amount ($paymentMethod) - $description",
                    newValue = "₹$amount"
                )
            )

            Result.success(expenseId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordManualCashMovement(
        type: CashTransactionType,
        amount: Double,
        isCredit: Boolean,
        description: String,
        operatorName: String = "Owner"
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val openSession = cashDao.getCurrentOpenSessionDirect() ?: return@withContext Result.failure(Exception("No active register session open"))
            val newExpected = if (isCredit) openSession.expectedClosingCash + amount else openSession.expectedClosingCash - amount
            val newAdditions = if (type == CashTransactionType.ADDITION) openSession.totalCashAdditions + amount else openSession.totalCashAdditions
            val newWithdrawals = if (type == CashTransactionType.WITHDRAWAL) openSession.totalCashWithdrawals + amount else openSession.totalCashWithdrawals

            cashDao.updateSession(
                openSession.copy(
                    expectedClosingCash = newExpected,
                    totalCashAdditions = newAdditions,
                    totalCashWithdrawals = newWithdrawals
                )
            )

            cashDao.insertCashTransaction(
                CashTransaction(
                    sessionId = openSession.id,
                    type = type,
                    amount = amount,
                    isCredit = isCredit,
                    description = description,
                    operatorName = operatorName
                )
            )

            auditLogDao.insertAuditLog(
                AuditLog(
                    userName = operatorName,
                    userRole = UserRole.OWNER,
                    action = "CASH_ADJUSTMENT",
                    itemType = "CASH_DRAWER",
                    itemId = openSession.id.toString(),
                    details = "${type.displayName}: ₹$amount. Reason: $description",
                    newValue = "₹$amount"
                )
            )

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // 7. CUSTOMER CLASSIFICATION & REPEAT ANALYTICS
    // ----------------------------------------------------
    private fun recalculateCustomerStats(
        customer: Customer,
        additionalSpend: Double,
        isOnline: Boolean
    ): Customer {
        val totalPurchases = customer.totalPurchases + 1
        val onlinePurchases = if (isOnline) customer.onlinePurchases + 1 else customer.onlinePurchases
        val offlinePurchases = if (!isOnline) customer.offlinePurchases + 1 else customer.offlinePurchases
        val totalSpent = customer.totalAmountSpent + additionalSpend
        val avgPurchase = if (totalPurchases > 0) totalSpent / totalPurchases else 0.0

        val tier = when {
            totalPurchases >= 5 -> CustomerRepeatTier.REGULAR
            totalPurchases >= 2 -> CustomerRepeatTier.RETURNING
            else -> CustomerRepeatTier.NEW
        }

        return customer.copy(
            totalPurchases = totalPurchases,
            onlinePurchases = onlinePurchases,
            offlinePurchases = offlinePurchases,
            totalAmountSpent = totalSpent,
            averagePurchaseValue = avgPurchase,
            lastPurchaseDate = System.currentTimeMillis(),
            repeatTier = tier
        )
    }

    suspend fun createOrUpdateCustomer(customer: Customer): Long = withContext(Dispatchers.IO) {
        if (customer.id == 0L) {
            customerDao.insertCustomer(customer)
        } else {
            customerDao.updateCustomer(customer)
            customer.id
        }
    }

    suspend fun addCustomerAddress(address: CustomerAddress): Long = withContext(Dispatchers.IO) {
        customerDao.insertAddress(address)
    }

    // ----------------------------------------------------
    // 8. PRODUCT CRUD & SETTINGS
    // ----------------------------------------------------
    suspend fun saveProduct(product: Product, operatorName: String = "Owner"): Long = withContext(Dispatchers.IO) {
        if (product.id == 0L) {
            val id = productDao.insertProduct(product)
            productDao.insertMovement(
                InventoryMovement(
                    productId = id,
                    productName = product.name,
                    quantity = product.currentStock,
                    movementType = MovementType.MANUAL_ADJUSTMENT,
                    previousStock = 0.0,
                    newStock = product.currentStock,
                    responsibleUser = operatorName,
                    reason = "Product Initial Creation"
                )
            )
            auditLogDao.insertAuditLog(
                AuditLog(
                    userName = operatorName,
                    userRole = UserRole.OWNER,
                    action = "ADD_PRODUCT",
                    itemType = "PRODUCT",
                    itemId = id.toString(),
                    details = "Created product ${product.name} (Stock: ${product.currentStock}, Price: ₹${product.sellingPrice})",
                    newValue = product.name
                )
            )
            id
        } else {
            val old = productDao.getProductById(product.id)
            productDao.updateProduct(product)
            auditLogDao.insertAuditLog(
                AuditLog(
                    userName = operatorName,
                    userRole = UserRole.OWNER,
                    action = "UPDATE_PRODUCT",
                    itemType = "PRODUCT",
                    itemId = product.id.toString(),
                    details = "Updated product ${product.name}",
                    previousValue = "₹${old?.sellingPrice ?: 0.0}",
                    newValue = "₹${product.sellingPrice}"
                )
            )
            product.id
        }
    }

    suspend fun deleteProduct(productId: Long, operatorName: String = "Owner"): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val p = productDao.getProductById(productId)
            productDao.deleteProduct(productId)
            auditLogDao.insertAuditLog(
                AuditLog(
                    userName = operatorName,
                    userRole = UserRole.OWNER,
                    action = "DELETE_PRODUCT",
                    itemType = "PRODUCT",
                    itemId = productId.toString(),
                    details = "Deleted product ${p?.name ?: productId}",
                    previousValue = p?.name ?: ""
                )
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateSettings(settings: ShopSettings, operatorName: String = "Owner") = withContext(Dispatchers.IO) {
        shopSettingsDao.updateSettings(settings)
        auditLogDao.insertAuditLog(
            AuditLog(
                userName = operatorName,
                userRole = UserRole.OWNER,
                action = "UPDATE_SHOP_SETTINGS",
                itemType = "SETTINGS",
                itemId = "1",
                details = "Updated shop configuration and business rules",
                newValue = settings.shopName
            )
        )
    }

    suspend fun saveEmployee(employee: Employee, operatorName: String = "Owner") = withContext(Dispatchers.IO) {
        if (employee.id == 0L) {
            employeeDao.insertEmployee(employee)
        } else {
            employeeDao.updateEmployee(employee)
        }
        auditLogDao.insertAuditLog(
            AuditLog(
                userName = operatorName,
                userRole = UserRole.OWNER,
                action = "MANAGE_EMPLOYEE",
                itemType = "EMPLOYEE",
                itemId = employee.id.toString(),
                details = "Updated employee ${employee.name} (${employee.role.displayName})",
                newValue = employee.role.name
            )
        )
    }

    suspend fun deleteEmployee(id: Long, operatorName: String = "Owner") = withContext(Dispatchers.IO) {
        employeeDao.deleteEmployee(id)
        auditLogDao.insertAuditLog(
            AuditLog(
                userName = operatorName,
                userRole = UserRole.OWNER,
                action = "DELETE_EMPLOYEE",
                itemType = "EMPLOYEE",
                itemId = id.toString(),
                details = "Removed employee id $id"
            )
        )
    }

    suspend fun markNotificationAsRead(id: Long) = withContext(Dispatchers.IO) {
        notificationDao.markAsRead(id)
    }

    suspend fun markAllNotificationsAsRead() = withContext(Dispatchers.IO) {
        notificationDao.markAllAsRead()
    }
}
