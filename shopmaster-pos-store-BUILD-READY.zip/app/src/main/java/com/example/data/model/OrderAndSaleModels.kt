package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class DeliveryType(val displayName: String) {
    HOME_DELIVERY("Home Delivery"),
    PICKUP("Shop Pickup")
}

enum class PaymentMethod(val displayName: String) {
    CASH("Cash on Delivery / Counter"),
    CASH_AT_PICKUP("Cash at Pickup"),
    UPI("UPI / QR Payment"),
    CARD("Debit / Credit Card"),
    OTHER("Other")
}

enum class PaymentStatus(val displayName: String) {
    PENDING("Pending"),
    PAID("Paid"),
    REFUNDED("Refunded"),
    FAILED("Failed")
}

enum class OrderStatus(val displayName: String, val stepIndex: Int) {
    ORDER_RECEIVED("Order Received", 1),
    CONFIRMED("Confirmed", 2),
    PREPARING("Preparing", 3),
    OUT_FOR_DELIVERY("Out for Delivery", 4),
    READY_FOR_PICKUP("Ready for Pickup", 4),
    DELIVERED("Delivered", 5),
    COMPLETED("Completed", 6),
    CANCELLED("Cancelled", -1),
    REFUNDED("Refunded", -2)
}

@Entity(
    tableName = "orders",
    foreignKeys = [
        ForeignKey(
            entity = Customer::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.SET_DEFAULT
        )
    ],
    indices = [Index(value = ["customerId"]), Index(value = ["createdAt"]), Index(value = ["orderStatus"])]
)
data class Order(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderNumber: String,
    val customerId: Long = 0,
    val customerName: String,
    val customerPhone: String,
    val deliveryType: DeliveryType = DeliveryType.HOME_DELIVERY,
    val deliveryAddress: String = "",
    val deliveryInstructions: String = "",
    val subtotal: Double,
    val deliveryCharge: Double = 0.0,
    val discount: Double = 0.0,
    val totalAmount: Double,
    val paymentMethod: PaymentMethod = PaymentMethod.CASH,
    val paymentStatus: PaymentStatus = PaymentStatus.PENDING,
    val orderStatus: OrderStatus = OrderStatus.ORDER_RECEIVED,
    val assignedDeliveryStaffId: Long? = null,
    val assignedDeliveryStaffName: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "order_items",
    foreignKeys = [
        ForeignKey(
            entity = Order::class,
            parentColumns = ["id"],
            childColumns = ["orderId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Product::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index(value = ["orderId"]), Index(value = ["productId"])]
)
data class OrderItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: Long,
    val productId: Long,
    val productName: String,
    val unitPrice: Double,
    val costPrice: Double,
    val unit: String,
    val quantity: Double,
    val totalPrice: Double
)

@Entity(
    tableName = "offline_sales",
    indices = [Index(value = ["customerId"]), Index(value = ["createdAt"])]
)
data class OfflineSale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceNumber: String,
    val customerId: Long = 0,
    val customerName: String = "Walk-in Customer",
    val customerPhone: String = "",
    val cashierName: String = "Cashier",
    val subtotal: Double,
    val discount: Double = 0.0,
    val tax: Double = 0.0,
    val totalAmount: Double,
    val paymentMethod: PaymentMethod = PaymentMethod.CASH,
    val paymentStatus: PaymentStatus = PaymentStatus.PAID,
    val isVoided: Boolean = false,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "offline_sale_items",
    foreignKeys = [
        ForeignKey(
            entity = OfflineSale::class,
            parentColumns = ["id"],
            childColumns = ["saleId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Product::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index(value = ["saleId"]), Index(value = ["productId"])]
)
data class OfflineSaleItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val productId: Long,
    val productName: String,
    val unitPrice: Double,
    val costPrice: Double,
    val unit: String,
    val quantity: Double,
    val totalPrice: Double
)
