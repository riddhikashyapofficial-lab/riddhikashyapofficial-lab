package com.example.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderStatus
import com.example.data.model.UserRole
import com.example.ui.analytics.AnalyticsAndReportsScreen
import com.example.ui.cash.CashManagementScreen
import com.example.ui.components.formatDateTime
import com.example.ui.customer.CustomerMainScreen
import com.example.ui.customers.CustomerManagementScreen
import com.example.ui.delivery.DeliveryStaffScreen
import com.example.ui.inventory.InventoryMainScreen
import com.example.ui.orders.OrdersManagementScreen
import com.example.ui.pos.PosScreen
import com.example.ui.settings.SettingsAndAuditScreen
import com.example.ui.staff.StaffManagementScreen
import com.example.ui.theme.PrimaryEmerald
import com.example.ui.theme.StatusWarningBg

enum class AdminSubScreen {
    CUSTOMERS,
    STAFF,
    SETTINGS_AUDIT
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopMainApp(
    viewModel: ShopViewModel,
    modifier: Modifier = Modifier
) {
    val currentRole by viewModel.currentRole.collectAsState()
    val operatorName by viewModel.currentOperatorName.collectAsState()
    val shopSettings by viewModel.shopSettings.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val notifications by viewModel.notifications.collectAsState()

    var activeTab by remember { mutableStateOf("pos") }
    var activeAdminSubScreen by remember { mutableStateOf(AdminSubScreen.CUSTOMERS) }
    var showRoleMenu by remember { mutableStateOf(false) }
    var showNotificationsSheet by remember { mutableStateOf(false) }

    val pendingOrdersCount = orders.count { it.orderStatus == OrderStatus.ORDER_RECEIVED || it.orderStatus == OrderStatus.CONFIRMED }
    val unreadNotifsCount = notifications.count { !it.isRead }

    // When role changes, switch default active tab
    val onRoleSelected: (UserRole) -> Unit = { r ->
        viewModel.setCurrentRole(r)
        when (r) {
            UserRole.CUSTOMER -> activeTab = "customer"
            UserRole.DELIVERY_STAFF -> activeTab = "delivery"
            UserRole.STOCK_STAFF -> activeTab = "inventory"
            UserRole.CASHIER -> activeTab = "pos"
            UserRole.MANAGER, UserRole.OWNER -> activeTab = "pos"
        }
    }

    Scaffold(
        topBar = {
            if (currentRole != UserRole.CUSTOMER) {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Store, contentDescription = null, tint = PrimaryEmerald, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = shopSettings?.shopName ?: "FreshMart Super Store",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "${currentRole.displayName} • $operatorName",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    actions = {
                        // Role Switcher
                        Box {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier
                                    .clickable { showRoleMenu = true }
                                    .padding(end = 6.dp)
                                    .testTag("role_switcher_chip")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.SwitchAccount, contentDescription = null, tint = PrimaryEmerald, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = currentRole.displayName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = showRoleMenu,
                                onDismissRequest = { showRoleMenu = false }
                            ) {
                                UserRole.values().forEach { role ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = if (role == UserRole.CUSTOMER) "🛒 Customer (Online Ordering)" else "${role.displayName} Mode",
                                                fontWeight = if (role == currentRole) FontWeight.Bold else FontWeight.Normal,
                                                color = if (role == currentRole) PrimaryEmerald else MaterialTheme.colorScheme.onSurface
                                            )
                                        },
                                        onClick = {
                                            onRoleSelected(role)
                                            showRoleMenu = false
                                        }
                                    )
                                }
                            }
                        }

                        // Alerts Bell Icon
                        IconButton(
                            onClick = { showNotificationsSheet = true },
                            modifier = Modifier.testTag("notifications_bell_btn")
                        ) {
                            BadgedBox(
                                badge = {
                                    if (unreadNotifsCount > 0) {
                                        Badge(containerColor = MaterialTheme.colorScheme.error) {
                                            Text(unreadNotifsCount.toString())
                                        }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Notifications, contentDescription = "Notifications")
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        },
        bottomBar = {
            if (currentRole != UserRole.CUSTOMER) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    if (currentRole == UserRole.DELIVERY_STAFF) {
                        NavigationBarItem(
                            selected = activeTab == "delivery",
                            onClick = { activeTab = "delivery" },
                            icon = { Icon(Icons.Default.DirectionsBike, contentDescription = "Delivery") },
                            label = { Text("My Runs") },
                            modifier = Modifier.testTag("nav_delivery"),
                            colors = NavigationBarItemDefaults.colors(indicatorColor = PrimaryEmerald.copy(alpha = 0.2f))
                        )
                        NavigationBarItem(
                            selected = activeTab == "orders",
                            onClick = { activeTab = "orders" },
                            icon = { Icon(Icons.Default.Receipt, contentDescription = "Orders") },
                            label = { Text("All Orders") },
                            modifier = Modifier.testTag("nav_orders"),
                            colors = NavigationBarItemDefaults.colors(indicatorColor = PrimaryEmerald.copy(alpha = 0.2f))
                        )
                    } else if (currentRole == UserRole.STOCK_STAFF) {
                        NavigationBarItem(
                            selected = activeTab == "inventory",
                            onClick = { activeTab = "inventory" },
                            icon = { Icon(Icons.Default.Inventory, contentDescription = "Inventory") },
                            label = { Text("Master Stock") },
                            modifier = Modifier.testTag("nav_inventory"),
                            colors = NavigationBarItemDefaults.colors(indicatorColor = PrimaryEmerald.copy(alpha = 0.2f))
                        )
                        NavigationBarItem(
                            selected = activeTab == "orders",
                            onClick = { activeTab = "orders" },
                            icon = { Icon(Icons.Default.Receipt, contentDescription = "Orders") },
                            label = { Text("Packing Orders") },
                            modifier = Modifier.testTag("nav_orders"),
                            colors = NavigationBarItemDefaults.colors(indicatorColor = PrimaryEmerald.copy(alpha = 0.2f))
                        )
                    } else {
                        // Owner / Manager / Cashier
                        NavigationBarItem(
                            selected = activeTab == "pos",
                            onClick = { activeTab = "pos" },
                            icon = { Icon(Icons.Default.PointOfSale, contentDescription = "POS") },
                            label = { Text("POS Bill") },
                            modifier = Modifier.testTag("nav_pos"),
                            colors = NavigationBarItemDefaults.colors(indicatorColor = PrimaryEmerald.copy(alpha = 0.2f))
                        )
                        NavigationBarItem(
                            selected = activeTab == "inventory",
                            onClick = { activeTab = "inventory" },
                            icon = { Icon(Icons.Default.Inventory, contentDescription = "Inventory") },
                            label = { Text("Stock") },
                            modifier = Modifier.testTag("nav_inventory"),
                            colors = NavigationBarItemDefaults.colors(indicatorColor = PrimaryEmerald.copy(alpha = 0.2f))
                        )
                        NavigationBarItem(
                            selected = activeTab == "orders",
                            onClick = { activeTab = "orders" },
                            icon = {
                                BadgedBox(badge = { if (pendingOrdersCount > 0) Badge { Text(pendingOrdersCount.toString()) } }) {
                                    Icon(Icons.Default.Receipt, contentDescription = "Orders")
                                }
                            },
                            label = { Text("Orders") },
                            modifier = Modifier.testTag("nav_orders"),
                            colors = NavigationBarItemDefaults.colors(indicatorColor = PrimaryEmerald.copy(alpha = 0.2f))
                        )
                        NavigationBarItem(
                            selected = activeTab == "cash",
                            onClick = { activeTab = "cash" },
                            icon = { Icon(Icons.Default.AttachMoney, contentDescription = "Cash") },
                            label = { Text("Drawer") },
                            modifier = Modifier.testTag("nav_cash"),
                            colors = NavigationBarItemDefaults.colors(indicatorColor = PrimaryEmerald.copy(alpha = 0.2f))
                        )

                        if (currentRole == UserRole.OWNER || currentRole == UserRole.MANAGER) {
                            NavigationBarItem(
                                selected = activeTab == "analytics",
                                onClick = { activeTab = "analytics" },
                                icon = { Icon(Icons.Default.Analytics, contentDescription = "Analytics") },
                                label = { Text("P&L") },
                                modifier = Modifier.testTag("nav_analytics"),
                                colors = NavigationBarItemDefaults.colors(indicatorColor = PrimaryEmerald.copy(alpha = 0.2f))
                            )
                            NavigationBarItem(
                                selected = activeTab == "more",
                                onClick = { activeTab = "more" },
                                icon = { Icon(Icons.Default.MoreHoriz, contentDescription = "More") },
                                label = { Text("Admin") },
                                modifier = Modifier.testTag("nav_more"),
                                colors = NavigationBarItemDefaults.colors(indicatorColor = PrimaryEmerald.copy(alpha = 0.2f))
                            )
                        }
                    }
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (currentRole == UserRole.CUSTOMER) {
                CustomerMainScreen(viewModel = viewModel)
            } else {
                when (activeTab) {
                    "pos" -> PosScreen(viewModel = viewModel)
                    "inventory" -> InventoryMainScreen(viewModel = viewModel)
                    "orders" -> OrdersManagementScreen(viewModel = viewModel)
                    "delivery" -> DeliveryStaffScreen(viewModel = viewModel)
                    "cash" -> CashManagementScreen(viewModel = viewModel)
                    "analytics" -> AnalyticsAndReportsScreen(viewModel = viewModel)
                    "more" -> {
                        AdminHubScreen(
                            viewModel = viewModel,
                            currentSub = activeAdminSubScreen,
                            onSelectSub = { activeAdminSubScreen = it }
                        )
                    }
                    else -> PosScreen(viewModel = viewModel)
                }
            }
        }
    }

    // Notifications Bottom Sheet
    if (showNotificationsSheet) {
        val sheetState = rememberModalBottomSheetState()
        ModalBottomSheet(
            onDismissRequest = { showNotificationsSheet = false },
            sheetState = sheetState
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
                Text("Notifications & Alerts", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))
                LazyColumn(modifier = Modifier.fillMaxWidth().height(300.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (notifications.isEmpty()) {
                        item { Text("No notifications at this time.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    } else {
                        items(notifications) { n ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = if (n.isRead) MaterialTheme.colorScheme.surfaceVariant else StatusWarningBg)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(n.title, fontWeight = FontWeight.Bold)
                                    Text(n.message, fontSize = 12.sp)
                                    Text(formatDateTime(n.timestamp), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
fun AdminHubScreen(
    viewModel: ShopViewModel,
    currentSub: AdminSubScreen,
    onSelectSub: (AdminSubScreen) -> Unit
) {
    val currentRole by viewModel.currentRole.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (currentSub == AdminSubScreen.CUSTOMERS) PrimaryEmerald else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSelectSub(AdminSubScreen.CUSTOMERS) }
                ) {
                    Text(
                        text = "Customers",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (currentSub == AdminSubScreen.CUSTOMERS) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }

                if (currentRole == UserRole.OWNER) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (currentSub == AdminSubScreen.STAFF) PrimaryEmerald else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelectSub(AdminSubScreen.STAFF) }
                    ) {
                        Text(
                            text = "Staff & Roles",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (currentSub == AdminSubScreen.STAFF) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 8.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }

                if (currentRole == UserRole.OWNER) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (currentSub == AdminSubScreen.SETTINGS_AUDIT) PrimaryEmerald else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelectSub(AdminSubScreen.SETTINGS_AUDIT) }
                    ) {
                        Text(
                            text = "Settings & Audit",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (currentSub == AdminSubScreen.SETTINGS_AUDIT) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 8.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        }

        when (currentSub) {
            AdminSubScreen.CUSTOMERS -> CustomerManagementScreen(viewModel = viewModel)
            AdminSubScreen.STAFF -> StaffManagementScreen(viewModel = viewModel)
            AdminSubScreen.SETTINGS_AUDIT -> SettingsAndAuditScreen(viewModel = viewModel)
        }
    }
}
