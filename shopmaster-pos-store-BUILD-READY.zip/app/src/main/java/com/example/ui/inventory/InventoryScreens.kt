package com.example.ui.inventory

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Category
import com.example.data.model.MovementType
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import com.example.data.model.PurchaseOrderItem
import com.example.data.model.Supplier
import com.example.ui.ShopViewModel
import com.example.ui.components.StatCard
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatCurrency
import com.example.ui.components.formatDateTime
import com.example.ui.theme.PrimaryEmerald
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorBg
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessBg
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningBg

@Composable
fun InventoryMainScreen(
    viewModel: ShopViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var showAddProductDialog by remember { mutableStateOf(false) }
    var productToEdit by remember { mutableStateOf<Product?>(null) }
    var productToAdjust by remember { mutableStateOf<Product?>(null) }
    var showStockInDialog by remember { mutableStateOf(false) }

    val products by viewModel.products.collectAsState()
    val lowStockList by viewModel.lowStockProducts.collectAsState()
    val movements by viewModel.movements.collectAsState()
    val settings by viewModel.shopSettings.collectAsState()
    val currency = settings?.currencySymbol ?: "₹"

    val totalStockValue = products.sumOf { it.currentStock * it.costPrice }

    Column(modifier = modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = PrimaryEmerald
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Stock Overview", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.Inventory, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Movements Log", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        when (selectedTab) {
            0 -> {
                InventoryOverviewTab(
                    viewModel = viewModel,
                    products = products,
                    lowStockCount = lowStockList.size,
                    totalValuation = totalStockValue,
                    currency = currency,
                    onAddProduct = { showAddProductDialog = true },
                    onEditProduct = { productToEdit = it },
                    onAdjustStock = { productToAdjust = it },
                    onStockIn = { showStockInDialog = true }
                )
            }
            1 -> {
                InventoryMovementsTab(movements = movements, currency = currency)
            }
        }
    }

    // Dialogs
    if (showAddProductDialog || productToEdit != null) {
        AddEditProductDialog(
            product = productToEdit,
            categories = viewModel.categories.collectAsState().value,
            onDismiss = {
                showAddProductDialog = false
                productToEdit = null
            },
            onSave = { prod ->
                viewModel.saveProduct(prod)
                showAddProductDialog = false
                productToEdit = null
            },
            onDelete = { id ->
                viewModel.deleteProduct(id)
                showAddProductDialog = false
                productToEdit = null
            }
        )
    }

    productToAdjust?.let { prod ->
        AdjustStockDialog(
            product = prod,
            onDismiss = { productToAdjust = null },
            onConfirm = { qtyChange, movementType, reason ->
                viewModel.adjustStock(prod.id, qtyChange, movementType, reason)
                productToAdjust = null
            }
        )
    }

    if (showStockInDialog) {
        StockInPurchaseDialog(
            viewModel = viewModel,
            onDismiss = { showStockInDialog = false }
        )
    }
}

@Composable
fun InventoryOverviewTab(
    viewModel: ShopViewModel,
    products: List<Product>,
    lowStockCount: Int,
    totalValuation: Double,
    currency: String,
    onAddProduct: () -> Unit,
    onEditProduct: (Product) -> Unit,
    onAdjustStock: (Product) -> Unit,
    onStockIn: () -> Unit
) {
    var searchStr by remember { mutableStateOf("") }
    var onlyLowStock by remember { mutableStateOf(false) }

    val filteredProducts = products.filter { p ->
        val matchesSearch = p.name.contains(searchStr, ignoreCase = true) || p.sku.contains(searchStr, ignoreCase = true) || p.barcode.contains(searchStr, ignoreCase = true)
        val matchesLowStock = !onlyLowStock || p.currentStock <= p.minStockLevel
        matchesSearch && matchesLowStock
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // KPI Summary Cards
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard(
                    title = "Total Products",
                    value = products.size.toString(),
                    subtitle = "${products.sumOf { it.currentStock }.toInt()} units",
                    icon = Icons.Default.Inventory,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Low Stock Alerts",
                    value = lowStockCount.toString(),
                    subtitle = "Needs reorder",
                    icon = Icons.Default.Warning,
                    iconBgColor = StatusWarningBg,
                    iconTint = StatusWarning,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            StatCard(
                title = "Total Inventory Valuation (at Cost)",
                value = formatCurrency(totalValuation, currency),
                subtitle = "Total purchase value stored in shop",
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Action Buttons Row
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onAddProduct,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f).testTag("add_new_product_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Product")
                }

                Button(
                    onClick = onStockIn,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f).testTag("stock_in_purchase_btn")
                ) {
                    Icon(Icons.Default.LocalShipping, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Stock In / PO", color = MaterialTheme.colorScheme.onSecondaryContainer)
                }
            }
        }

        // Search & Filter
        item {
            OutlinedTextField(
                value = searchStr,
                onValueChange = { searchStr = it },
                placeholder = { Text("Search product name, SKU or barcode...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilterChip(
                    selected = onlyLowStock,
                    onClick = { onlyLowStock = !onlyLowStock },
                    label = { Text("⚠️ Show Low Stock Only ($lowStockCount)") },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = StatusWarningBg)
                )
            }
        }

        // Products List
        items(filteredProducts) { prod ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(prod.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("SKU: ${prod.sku.ifBlank { "N/A" }} | Barcode: ${prod.barcode.ifBlank { "N/A" }}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        if (prod.currentStock <= 0.0) {
                            StatusBadge(text = "Out of Stock", containerColor = StatusErrorBg, contentColor = StatusError)
                        } else if (prod.currentStock <= prod.minStockLevel) {
                            StatusBadge(text = "Low Stock: ${prod.currentStock.toInt()} ${prod.unit}", containerColor = StatusWarningBg, contentColor = StatusWarning)
                        } else {
                            StatusBadge(text = "${prod.currentStock.toInt()} ${prod.unit}", containerColor = StatusSuccessBg, contentColor = StatusSuccess)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Selling: ${formatCurrency(prod.sellingPrice, currency)}", fontWeight = FontWeight.Bold, color = PrimaryEmerald)
                            val margin = if (prod.sellingPrice > 0) ((prod.sellingPrice - prod.costPrice) / prod.sellingPrice * 100).toInt() else 0
                            Text("Cost: ${formatCurrency(prod.costPrice, currency)} ($margin% margin)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { onAdjustStock(prod) },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Adjust", fontSize = 12.sp)
                            }

                            Button(
                                onClick = { onEditProduct(prod) },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Edit", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSecondaryContainer)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InventoryMovementsTab(
    movements: List<com.example.data.model.InventoryMovement>,
    currency: String
) {
    if (movements.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No inventory movements recorded yet.")
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Master Inventory Real-time Stream", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("All online sales, offline sales, stock receipts, and damages synchronize here.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        items(movements) { m ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(m.productName, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(m.reason, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "${formatDateTime(m.timestamp)} • User: ${m.responsibleUser}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        val isPositive = m.quantity > 0
                        val qtyText = if (isPositive) "+${m.quantity.toInt()}" else "${m.quantity.toInt()}"
                        Text(
                            text = qtyText,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = if (isPositive) StatusSuccess else StatusError
                        )
                        Text(
                            text = "${m.previousStock.toInt()} ➔ ${m.newStock.toInt()}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        StatusBadge(
                            text = m.movementType.displayName,
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditProductDialog(
    product: Product?,
    categories: List<Category>,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit,
    onDelete: (Long) -> Unit
) {
    val isEdit = product != null
    var name by remember { mutableStateOf(product?.name ?: "") }
    var selectedCategoryId by remember { mutableStateOf(product?.categoryId ?: categories.firstOrNull()?.id ?: 1L) }
    var description by remember { mutableStateOf(product?.description ?: "") }
    var sellingPrice by remember { mutableStateOf(product?.sellingPrice?.toString() ?: "") }
    var costPrice by remember { mutableStateOf(product?.costPrice?.toString() ?: "") }
    var currentStock by remember { mutableStateOf(product?.currentStock?.toInt()?.toString() ?: "0") }
    var minStock by remember { mutableStateOf(product?.minStockLevel?.toInt()?.toString() ?: "5") }
    var unit by remember { mutableStateOf(product?.unit ?: "pcs") }
    var sku by remember { mutableStateOf(product?.sku ?: "") }
    var barcode by remember { mutableStateOf(product?.barcode ?: "") }
    var allowBackorders by remember { mutableStateOf(product?.allowBackorders ?: false) }

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) {
            LazyColumn(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text(if (isEdit) "Edit Product" else "Add New Product", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                }

                item {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Product Name *") }, modifier = Modifier.fillMaxWidth().testTag("product_name_input"))
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = sellingPrice, onValueChange = { sellingPrice = it }, label = { Text("Selling Price *") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = costPrice, onValueChange = { costPrice = it }, label = { Text("Cost Price *") }, modifier = Modifier.weight(1f))
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = currentStock, onValueChange = { currentStock = it }, label = { Text("Current Stock *") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = minStock, onValueChange = { minStock = it }, label = { Text("Low Stock Alert Level") }, modifier = Modifier.weight(1f))
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text("Unit (pcs/kg/ltr/pack)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = sku, onValueChange = { sku = it }, label = { Text("SKU Code") }, modifier = Modifier.weight(1f))
                    }
                }

                item {
                    OutlinedTextField(value = barcode, onValueChange = { barcode = it }, label = { Text("Barcode Number") }, modifier = Modifier.fillMaxWidth())
                }

                item {
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
                }

                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = allowBackorders, onCheckedChange = { allowBackorders = it })
                        Text("Allow backorders when out of stock")
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (isEdit) {
                            OutlinedButton(
                                onClick = { onDelete(product.id) },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusError),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Delete")
                            }
                        }
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                            Text("Cancel")
                        }
                        Button(
                            onClick = {
                                val sPrice = sellingPrice.toDoubleOrNull() ?: 0.0
                                val cPrice = costPrice.toDoubleOrNull() ?: 0.0
                                val stock = currentStock.toDoubleOrNull() ?: 0.0
                                val mStock = minStock.toDoubleOrNull() ?: 5.0
                                if (name.isNotBlank() && sPrice > 0) {
                                    val newP = Product(
                                        id = product?.id ?: 0L,
                                        name = name,
                                        categoryId = selectedCategoryId,
                                        description = description,
                                        sellingPrice = sPrice,
                                        costPrice = cPrice,
                                        currentStock = stock,
                                        minStockLevel = mStock,
                                        unit = unit.ifBlank { "pcs" },
                                        sku = sku,
                                        barcode = barcode,
                                        allowBackorders = allowBackorders,
                                        isAvailable = stock > 0 || allowBackorders
                                    )
                                    onSave(newP)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                            modifier = Modifier.weight(1.5f).testTag("save_product_btn")
                        ) {
                            Text("Save Product")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdjustStockDialog(
    product: Product,
    onDismiss: () -> Unit,
    onConfirm: (Double, MovementType, String) -> Unit
) {
    var quantityInput by remember { mutableStateOf("1") }
    var isDeduction by remember { mutableStateOf(true) }
    var selectedType by remember { mutableStateOf(MovementType.DAMAGED) }
    var reason by remember { mutableStateOf("") }

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Adjust Stock: ${product.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Current Stock: ${product.currentStock.toInt()} ${product.unit}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedType == MovementType.DAMAGED,
                        onClick = {
                            selectedType = MovementType.DAMAGED
                            isDeduction = true
                        },
                        label = { Text("Damaged (-)") }
                    )
                    FilterChip(
                        selected = selectedType == MovementType.LOST,
                        onClick = {
                            selectedType = MovementType.LOST
                            isDeduction = true
                        },
                        label = { Text("Lost / Expired (-)") }
                    )

                    FilterChip(
                        selected = selectedType == MovementType.MANUAL_ADJUSTMENT,
                        onClick = {
                            selectedType = MovementType.MANUAL_ADJUSTMENT
                            isDeduction = false
                        },
                        label = { Text("Found (+)") }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = quantityInput,
                    onValueChange = { quantityInput = it },
                    label = { Text("Quantity (${product.unit})") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Reason / Audit Note *") },
                    placeholder = { Text("e.g., Broken bottle in aisle 3") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val qty = quantityInput.toDoubleOrNull() ?: 1.0
                            val finalQty = if (isDeduction) -qty else qty
                            onConfirm(finalQty, selectedType, reason.ifBlank { "Stock Adjustment" })
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Confirm")
                    }
                }
            }
        }
    }
}

@Composable
fun StockInPurchaseDialog(
    viewModel: ShopViewModel,
    onDismiss: () -> Unit
) {
    val suppliers by viewModel.suppliers.collectAsState()
    val products by viewModel.products.collectAsState()

    var selectedSupplier by remember { mutableStateOf(suppliers.firstOrNull()) }
    var invoiceNumber by remember { mutableStateOf("PO-${System.currentTimeMillis() % 100000}") }
    var selectedProduct by remember { mutableStateOf(products.firstOrNull()) }
    var quantityInput by remember { mutableStateOf("20") }
    var costPriceInput by remember { mutableStateOf(selectedProduct?.costPrice?.toString() ?: "100") }
    var paymentMethod by remember { mutableStateOf(PaymentMethod.CASH) }
    var notes by remember { mutableStateOf("") }

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) {
            LazyColumn(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text("Stock Inward / Supplier PO", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Receive new stock directly into Master Inventory", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(6.dp))
                }

                item {
                    OutlinedTextField(
                        value = invoiceNumber,
                        onValueChange = { invoiceNumber = it },
                        label = { Text("Supplier Invoice / PO # *") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Text("Select Supplier:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(suppliers) { sup ->
                            FilterChip(
                                selected = selectedSupplier?.id == sup.id,
                                onClick = { selectedSupplier = sup },
                                label = { Text(sup.name) }
                            )
                        }
                    }
                }

                item {
                    Text("Select Product to Inward:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(products.take(6)) { p ->
                            FilterChip(
                                selected = selectedProduct?.id == p.id,
                                onClick = {
                                    selectedProduct = p
                                    costPriceInput = p.costPrice.toString()
                                },
                                label = { Text(p.name.take(15)) }
                            )
                        }
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = quantityInput,
                            onValueChange = { quantityInput = it },
                            label = { Text("Inward Qty (${selectedProduct?.unit ?: "pcs"})") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = costPriceInput,
                            onValueChange = { costPriceInput = it },
                            label = { Text("Purchase Cost (₹)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Text("Paid via:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = paymentMethod == PaymentMethod.CASH,
                            onClick = { paymentMethod = PaymentMethod.CASH },
                            label = { Text("Cash Drawer") }
                        )
                        FilterChip(
                            selected = paymentMethod == PaymentMethod.UPI,
                            onClick = { paymentMethod = PaymentMethod.UPI },
                            label = { Text("Bank / UPI") }
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("PO Notes (Optional)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                            Text("Cancel")
                        }
                        Button(
                            onClick = {
                                val sup = selectedSupplier
                                val prod = selectedProduct
                                val qty = quantityInput.toDoubleOrNull() ?: 0.0
                                val cost = costPriceInput.toDoubleOrNull() ?: 0.0
                                if (sup != null && prod != null && qty > 0) {
                                    val item = PurchaseOrderItem(
                                        purchaseOrderId = 0L,
                                        productId = prod.id,
                                        productName = prod.name,
                                        quantity = qty,
                                        purchasePrice = cost,
                                        total = qty * cost
                                    )
                                    viewModel.recordStockIn(
                                        supplier = sup,
                                        invoiceNumber = invoiceNumber,
                                        items = listOf(item),
                                        paymentMethod = paymentMethod,
                                        notes = notes,
                                        onSuccess = onDismiss
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                            modifier = Modifier.weight(1.5f).testTag("confirm_stock_in_btn")
                        ) {
                            Text("Confirm Stock In")
                        }
                    }
                }
            }
        }
    }
}
