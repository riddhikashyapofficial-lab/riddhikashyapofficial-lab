package com.example.ui.settings

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppNotification
import com.example.data.model.AuditLog
import com.example.data.model.ShopSettings
import com.example.ui.ShopViewModel
import com.example.ui.components.formatDateTime
import com.example.ui.theme.PrimaryEmerald
import com.example.ui.theme.StatusWarningBg

@Composable
fun SettingsAndAuditScreen(
    viewModel: ShopViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentSettings by viewModel.shopSettings.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()
    val notifications by viewModel.notifications.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }

    Column(modifier = modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = PrimaryEmerald
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Shop Profile", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Audit Trail", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Alerts (${notifications.size})", fontWeight = FontWeight.SemiBold) },
                icon = { Icon(Icons.Default.Notifications, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        when (selectedTab) {
            0 -> {
                val s = currentSettings ?: ShopSettings()
                ShopSettingsForm(
                    settings = s,
                    onSave = { updated ->
                        viewModel.updateSettings(updated)
                        Toast.makeText(context, "Shop Settings Updated Successfully!", Toast.LENGTH_SHORT).show()
                    }
                )
            }
            1 -> AuditTrailTab(logs = auditLogs)
            2 -> NotificationsTab(notifications = notifications)
        }
    }
}

@Composable
fun ShopSettingsForm(
    settings: ShopSettings,
    onSave: (ShopSettings) -> Unit
) {
    var shopName by remember(settings) { mutableStateOf(settings.shopName) }
    var phone by remember(settings) { mutableStateOf(settings.phone) }
    var email by remember(settings) { mutableStateOf(settings.email) }
    var address by remember(settings) { mutableStateOf(settings.address) }
    var openingHours by remember(settings) { mutableStateOf(settings.openingHours) }
    var currencySymbol by remember(settings) { mutableStateOf(settings.currencySymbol) }
    var taxPercentage by remember(settings) { mutableStateOf(settings.taxPercentage.toString()) }
    var isTaxEnabled by remember(settings) { mutableStateOf(settings.isTaxEnabled) }
    var freeDeliveryThreshold by remember(settings) { mutableStateOf(settings.freeDeliveryThreshold.toString()) }
    var deliveryCharge by remember(settings) { mutableStateOf(settings.deliveryCharge.toString()) }
    var minOrderValue by remember(settings) { mutableStateOf(settings.minOrderValue.toString()) }
    var invoiceHeader by remember(settings) { mutableStateOf(settings.invoiceHeader) }
    var invoiceFooter by remember(settings) { mutableStateOf(settings.invoiceFooter) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Store Identity & Contact Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        item {
            OutlinedTextField(
                value = shopName,
                onValueChange = { shopName = it },
                label = { Text("Shop Business Name *") },
                modifier = Modifier.fillMaxWidth().testTag("shop_name_field")
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Shop Email") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Shop Full Physical Address") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = openingHours,
                onValueChange = { openingHours = it },
                label = { Text("Operating / Store Timings") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text("Billing, Tax & Delivery Configurations", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Enable GST / Sales Tax on Bills", fontWeight = FontWeight.SemiBold)
                Switch(
                    checked = isTaxEnabled,
                    onCheckedChange = { isTaxEnabled = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = PrimaryEmerald)
                )
            }
        }

        if (isTaxEnabled) {
            item {
                OutlinedTextField(
                    value = taxPercentage,
                    onValueChange = { taxPercentage = it },
                    label = { Text("Default Tax / GST Percentage (%)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = freeDeliveryThreshold,
                    onValueChange = { freeDeliveryThreshold = it },
                    label = { Text("Free Delivery Threshold (₹)") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = deliveryCharge,
                    onValueChange = { deliveryCharge = it },
                    label = { Text("Delivery Fee (₹)") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            OutlinedTextField(
                value = minOrderValue,
                onValueChange = { minOrderValue = it },
                label = { Text("Minimum Order Value (₹)") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text("Thermal Print Receipt Customization", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        item {
            OutlinedTextField(
                value = invoiceHeader,
                onValueChange = { invoiceHeader = it },
                label = { Text("Receipt Header Tagline") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = invoiceFooter,
                onValueChange = { invoiceFooter = it },
                label = { Text("Receipt Footer Note") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = {
                    val updated = settings.copy(
                        shopName = shopName,
                        phone = phone,
                        email = email,
                        address = address,
                        openingHours = openingHours,
                        currencySymbol = currencySymbol,
                        taxPercentage = taxPercentage.toDoubleOrNull() ?: 5.0,
                        isTaxEnabled = isTaxEnabled,
                        freeDeliveryThreshold = freeDeliveryThreshold.toDoubleOrNull() ?: 500.0,
                        deliveryCharge = deliveryCharge.toDoubleOrNull() ?: 30.0,
                        minOrderValue = minOrderValue.toDoubleOrNull() ?: 150.0,
                        invoiceHeader = invoiceHeader,
                        invoiceFooter = invoiceFooter
                    )
                    onSave(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("save_shop_settings_btn")
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Save Shop Settings", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AuditTrailTab(logs: List<AuditLog>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("System Audit Trail & Security Logs", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Permanent record of all sales, stock adjustments, expense entries, and drawer operations.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        items(logs) { log ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(log.action, fontWeight = FontWeight.Bold)
                        Text(formatDateTime(log.timestamp), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(log.details, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("User: ${log.userName} (${log.userRole.displayName})", fontSize = 11.sp, color = PrimaryEmerald, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun NotificationsTab(notifications: List<AppNotification>) {
    if (notifications.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No new alerts.")
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(notifications) { notif ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (notif.isRead) MaterialTheme.colorScheme.surface else StatusWarningBg
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(notif.title, fontWeight = FontWeight.Bold)
                        Text(formatDateTime(notif.timestamp), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(notif.message, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
