package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CustomerRepeatTier
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentStatus
import com.example.data.model.ShopSettings
import com.example.data.model.UserRole
import com.example.ui.theme.FreshGreenContainer
import com.example.ui.theme.FreshGreenPrimary
import com.example.ui.theme.FreshGreenPrimaryDark
import com.example.ui.theme.GoldenAmber
import com.example.ui.theme.GoldenAmberLight
import com.example.ui.theme.OnFreshGreenContainer
import com.example.ui.theme.PrimaryEmerald
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorBg
import com.example.ui.theme.StatusInfo
import com.example.ui.theme.StatusInfoBg
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessBg
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningBg
import com.example.ui.theme.WarmPeachBackground
import com.example.ui.theme.WarmPeachBorder
import com.example.ui.theme.WarmPeachContainer
import com.example.ui.theme.WarmPeachSurface
import com.example.ui.theme.WarmPeachSurfaceVariant
import com.example.ui.theme.WarmSlateDark
import com.example.ui.theme.WarmSlateMuted
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

fun formatCurrency(amount: Double, symbol: String = "₹"): String {
    val formatter = NumberFormat.getNumberInstance(Locale.getDefault()).apply {
        maximumFractionDigits = 2
        minimumFractionDigits = if (amount % 1.0 == 0.0) 0 else 2
    }
    return "$symbol${formatter.format(amount)}"
}

fun formatDateTime(timestamp: Long?): String {
    if (timestamp == null || timestamp <= 0) return "N/A"
    val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
    return sdf.format(Date(timestamp))
}

fun formatDateOnly(timestamp: Long?): String {
    if (timestamp == null || timestamp <= 0) return "Never"
    val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    return sdf.format(Date(timestamp))
}

/**
 * Maps product or category names to appropriate vibrant emojis/icons
 */
fun getCategoryVisualIcon(name: String): String {
    val lower = name.lowercase()
    return when {
        lower.contains("fruit") -> "🍎"
        lower.contains("veg") -> "🥦"
        lower.contains("dairy") || lower.contains("milk") -> "🥛"
        lower.contains("snack") || lower.contains("biscuit") -> "🍪"
        lower.contains("beverage") || lower.contains("drink") || lower.contains("tea") -> "🧃"
        lower.contains("flour") || lower.contains("grain") || lower.contains("atta") -> "🌾"
        lower.contains("oil") || lower.contains("ghee") -> "🫒"
        lower.contains("spice") || lower.contains("masala") -> "🌶️"
        lower.contains("house") || lower.contains("clean") -> "🧼"
        lower.contains("care") || lower.contains("soap") -> "🧴"
        lower.contains("bakery") || lower.contains("bread") -> "🍞"
        else -> "🛍️"
    }
}

@Composable
fun StatusBadge(
    text: String,
    containerColor: Color,
    contentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = containerColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(20.dp),
        modifier = modifier
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun OrderStatusBadge(status: OrderStatus, modifier: Modifier = Modifier) {
    val (bg, textCol) = when (status) {
        OrderStatus.ORDER_RECEIVED -> Pair(FreshGreenContainer, FreshGreenPrimary)
        OrderStatus.CONFIRMED -> Pair(FreshGreenContainer, FreshGreenPrimaryDark)
        OrderStatus.PREPARING -> Pair(GoldenAmberLight, GoldenAmber)
        OrderStatus.OUT_FOR_DELIVERY, OrderStatus.READY_FOR_PICKUP -> Pair(GoldenAmberLight, GoldenAmber)
        OrderStatus.DELIVERED, OrderStatus.COMPLETED -> Pair(StatusSuccessBg, StatusSuccess)
        OrderStatus.CANCELLED, OrderStatus.REFUNDED -> Pair(StatusErrorBg, StatusError)
    }
    StatusBadge(text = status.displayName, containerColor = bg, contentColor = textCol, modifier = modifier)
}

@Composable
fun CustomerTierBadge(tier: CustomerRepeatTier, modifier: Modifier = Modifier) {
    val (bg, textCol) = when (tier) {
        CustomerRepeatTier.NEW -> Pair(Color(0xFFDBEAFE), Color(0xFF1E40AF))
        CustomerRepeatTier.RETURNING -> Pair(FreshGreenContainer, FreshGreenPrimary)
        CustomerRepeatTier.REGULAR -> Pair(Color(0xFFEDE9FE), Color(0xFF5B21B6))
        CustomerRepeatTier.OCCASIONAL -> Pair(GoldenAmberLight, GoldenAmber)
        CustomerRepeatTier.INACTIVE -> Pair(Color(0xFFF1F5F9), Color(0xFF64748B))
    }
    StatusBadge(text = tier.label, containerColor = bg, contentColor = textCol, modifier = modifier)
}

@Composable
fun StatCard(
    title: String,
    value: String,
    subtitle: String? = null,
    icon: ImageVector? = null,
    iconBgColor: Color = FreshGreenContainer,
    iconTint: Color = FreshGreenPrimary,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = WarmPeachSurface),
        shape = RoundedCornerShape(22.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, WarmPeachBorder),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = WarmSlateMuted,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = WarmSlateDark
                )
                if (subtitle != null) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = FreshGreenPrimary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            if (icon != null) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(iconBgColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

/**
 * Fresh Green pill quantity stepper with [-] QTY [+]
 */
@Composable
fun QuantityStepper(
    quantity: Double,
    unit: String = "pcs",
    onDecrease: () -> Unit,
    onIncrease: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(FreshGreenPrimary)
            .padding(horizontal = 4.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        IconButton(
            onClick = onDecrease,
            modifier = Modifier.size(30.dp).testTag("stepper_decrease")
        ) {
            Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = Color.White, modifier = Modifier.size(16.dp))
        }

        val displayQty = if (quantity % 1.0 == 0.0) quantity.toInt().toString() else "%.1f".format(quantity)
        Text(
            text = "$displayQty $unit",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        IconButton(
            onClick = onIncrease,
            modifier = Modifier.size(30.dp).testTag("stepper_increase")
        ) {
            Icon(Icons.Default.Add, contentDescription = "Increase", tint = Color.White, modifier = Modifier.size(16.dp))
        }
    }
}

/**
 * Visual Order Tracking Timeline
 */
@Composable
fun OrderTimelineTracker(
    currentStatus: OrderStatus,
    modifier: Modifier = Modifier
) {
    val stages = listOf(
        Pair("Order Received", OrderStatus.ORDER_RECEIVED),
        Pair("Confirmed", OrderStatus.CONFIRMED),
        Pair("Preparing", OrderStatus.PREPARING),
        Pair("Out for Delivery", OrderStatus.OUT_FOR_DELIVERY),
        Pair("Delivered", OrderStatus.DELIVERED)
    )

    val currentOrdinal = when (currentStatus) {
        OrderStatus.ORDER_RECEIVED -> 0
        OrderStatus.CONFIRMED -> 1
        OrderStatus.PREPARING -> 2
        OrderStatus.OUT_FOR_DELIVERY, OrderStatus.READY_FOR_PICKUP -> 3
        OrderStatus.DELIVERED, OrderStatus.COMPLETED -> 4
        OrderStatus.CANCELLED, OrderStatus.REFUNDED -> -1
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(WarmPeachSurface)
            .border(1.dp, WarmPeachBorder, RoundedCornerShape(20.dp))
            .padding(18.dp)
    ) {
        Text(
            text = "Live Order Journey",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = WarmSlateDark
        )
        Spacer(modifier = Modifier.height(14.dp))

        stages.forEachIndexed { index, (stageName, _) ->
            val isCompleted = index <= currentOrdinal && currentOrdinal != -1
            val isCurrent = index == currentOrdinal

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Step Circle
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(
                            if (isCompleted) FreshGreenPrimary else WarmPeachSurfaceVariant
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCompleted) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(WarmSlateMuted.copy(alpha = 0.5f))
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stageName,
                        fontWeight = if (isCurrent) FontWeight.Bold else if (isCompleted) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (isCompleted) FreshGreenPrimary else WarmSlateMuted,
                        fontSize = 13.sp
                    )
                }

                if (isCurrent) {
                    StatusBadge(
                        text = "In Progress",
                        containerColor = FreshGreenContainer,
                        contentColor = FreshGreenPrimary
                    )
                }
            }

            if (index < stages.size - 1) {
                Box(
                    modifier = Modifier
                        .padding(start = 13.dp)
                        .width(2.dp)
                        .height(20.dp)
                        .background(
                            if (index < currentOrdinal && currentOrdinal != -1) FreshGreenPrimary else WarmPeachBorder
                        )
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoleSelectorBottomSheet(
    currentRole: UserRole,
    onSelectRole: (UserRole) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState()
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = WarmPeachSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "Switch User Role & View",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = WarmSlateDark
            )
            Text(
                text = "Experience the app from customer storefront or staff POS & management consoles",
                style = MaterialTheme.typography.bodyMedium,
                color = WarmSlateMuted
            )
            Spacer(modifier = Modifier.height(16.dp))

            UserRole.values().forEach { role ->
                val isSelected = role == currentRole
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                        .clickable {
                            onSelectRole(role)
                            onDismiss()
                        }
                        .testTag("role_option_${role.name}"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) FreshGreenContainer else WarmPeachSurfaceVariant
                    ),
                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, FreshGreenPrimary) else null
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) FreshGreenPrimary else WarmPeachSurface),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (role) {
                                    UserRole.OWNER -> Icons.Default.Storefront
                                    UserRole.DELIVERY_STAFF -> Icons.Default.DirectionsBike
                                    UserRole.CUSTOMER -> Icons.Default.Person
                                    else -> Icons.Default.Person
                                },
                                contentDescription = null,
                                tint = if (isSelected) Color.White else WarmSlateDark
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (role == UserRole.CUSTOMER) "🛒 Customer Storefront" else role.displayName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) OnFreshGreenContainer else WarmSlateDark
                            )
                            Text(
                                text = role.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isSelected) OnFreshGreenContainer.copy(alpha = 0.8f) else WarmSlateMuted
                            )
                        }
                        if (isSelected) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = "Active",
                                tint = FreshGreenPrimary
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun SimpleBarChart(
    data: List<Pair<String, Double>>,
    modifier: Modifier = Modifier,
    barColor: Color = FreshGreenPrimary,
    symbol: String = "₹"
) {
    if (data.isEmpty()) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text("No sales data available for this range", color = WarmSlateMuted)
        }
        return
    }

    val maxVal = max(1.0, data.maxOf { it.second })

    Column(modifier = modifier.padding(8.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            data.forEach { (label, value) ->
                val ratio = (value / maxVal).toFloat()
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f).padding(horizontal = 4.dp)
                ) {
                    Text(
                        text = if (value >= 1000) "${(value / 1000).toInt()}k" else value.toInt().toString(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = WarmSlateDark
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.65f)
                            .height((120 * ratio).coerceAtLeast(6f).dp)
                            .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                            .background(
                                Brush.verticalGradient(
                                    listOf(barColor, barColor.copy(alpha = 0.7f))
                                )
                            )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = label,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = WarmSlateMuted
                    )
                }
            }
        }
    }
}

@Composable
fun ReceiptDialog(
    invoiceNumber: String,
    customerName: String,
    customerPhone: String,
    cashierName: String,
    items: List<Triple<String, Double, Double>>, // Name, qty, total
    subtotal: Double,
    discount: Double,
    tax: Double,
    total: Double,
    paymentMethod: String,
    shopSettings: ShopSettings?,
    onDismiss: () -> Unit
) {
    val currency = shopSettings?.currencySymbol ?: "₹"
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Text(
                    text = shopSettings?.shopName ?: "FreshMart Super Store",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.Black,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = shopSettings?.address ?: "Market Complex, Main Road",
                    fontSize = 12.sp,
                    color = Color.DarkGray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Tel: ${shopSettings?.phone ?: "+91 98765 43210"}",
                    fontSize = 12.sp,
                    color = Color.DarkGray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = Color.LightGray)
                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Bill #: $invoiceNumber", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    Text(formatDateTime(System.currentTimeMillis()), fontSize = 11.sp, color = Color.DarkGray)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Customer: $customerName", fontSize = 12.sp, color = Color.DarkGray)
                    Text("Cashier: $cashierName", fontSize = 12.sp, color = Color.DarkGray)
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = Color.LightGray)
                Spacer(modifier = Modifier.height(8.dp))

                // Items list
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text("Item", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black, modifier = Modifier.weight(1.8f))
                    Text("Qty", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black, modifier = Modifier.weight(0.6f), textAlign = TextAlign.Center)
                    Text("Amount", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                }
                Spacer(modifier = Modifier.height(4.dp))

                items.forEach { (name, qty, itemTotal) ->
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(name, fontSize = 12.sp, color = Color.Black, modifier = Modifier.weight(1.8f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val qtyStr = if (qty % 1.0 == 0.0) qty.toInt().toString() else "%.1f".format(qty)
                        Text(qtyStr, fontSize = 12.sp, color = Color.Black, modifier = Modifier.weight(0.6f), textAlign = TextAlign.Center)
                        Text(formatCurrency(itemTotal, currency), fontSize = 12.sp, color = Color.Black, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = Color.LightGray)
                Spacer(modifier = Modifier.height(6.dp))

                // Totals
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Subtotal", fontSize = 12.sp, color = Color.DarkGray)
                    Text(formatCurrency(subtotal, currency), fontSize = 12.sp, color = Color.Black)
                }
                if (discount > 0) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Discount", fontSize = 12.sp, color = FreshGreenPrimary)
                        Text("-${formatCurrency(discount, currency)}", fontSize = 12.sp, color = FreshGreenPrimary)
                    }
                }
                if (tax > 0) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("GST / Tax (${shopSettings?.taxPercentage ?: 5}%)", fontSize = 12.sp, color = Color.DarkGray)
                        Text(formatCurrency(tax, currency), fontSize = 12.sp, color = Color.Black)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("TOTAL AMOUNT", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    Text(formatCurrency(total, currency), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = FreshGreenPrimary)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Payment Mode", fontSize = 12.sp, color = Color.DarkGray)
                    Text(paymentMethod, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.Black)
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = shopSettings?.invoiceHeader ?: "Thank you for shopping with us!",
                    fontSize = 11.sp,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).testTag("receipt_close")
                    ) {
                        Text("Close")
                    }
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = FreshGreenPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).testTag("receipt_print")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Print / Share")
                    }
                }
            }
        }
    }
}
